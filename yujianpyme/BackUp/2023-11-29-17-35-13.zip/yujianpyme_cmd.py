#coding=utf-8
import sys
import os
from   os.path import abspath, dirname
sys.path.insert(0,abspath(dirname(__file__)))
import tkinter
from   tkinter import *
import Fun
ElementBGArray={}  
ElementBGArray_Resize={} 
ElementBGArray_IM={} 

def Form_1_onLoad(uiName):
    # 页面加载函数
    ListView = Fun.GetElement(uiName,'ListView_1')
    for i in range(100):
        Fun.AddRowText(uiName,"ListView_1",rowIndex='end',values=(i,'3212','4444'))
    pass
#RadioButton 'MDB's Event :Command
def RadioButton_9_onCommand(uiName,widgetName):
    Fun.SetValueList(uiName,'RadioButton',1)
    pass
#RadioButton '探测3XX's Event :Command
def RadioButton_15_onCommand(uiName,widgetName):
    pass

def ListView_1_onHeadingClicked(uiName,widgetName,columnname):
    pass

